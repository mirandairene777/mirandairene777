# Add the animation to your GitHub profile

1. Open https://github.com/mirandairene777/mirandairene777 (your profile README repository).
2. Upload the `assets` folder from this package into the repository root.
3. Keep the folder names exactly as `assets/field-journal-banner.png` and `assets/pixel-explorer.gif`.
4. In your existing `README.md`, add the image snippet from `README-animated-snippet.md` where you want the banner and walking explorer to appear.
5. Preview the README, then commit the changes.

The GIF is a looping pixel-art scene. GitHub README pages support repository-hosted images and relative paths; see GitHub's README and Markdown docs:
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes
- https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-syntax
