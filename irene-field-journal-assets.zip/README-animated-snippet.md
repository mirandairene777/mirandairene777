<!-- Irene's Field Journal: animated RPG explorer -->
<p align="center">
  <img
    src="./assets/field-journal-banner.png"
    width="100%"
    alt="Irene's Field Journal — pixel-art ruins, exploration, code, and faith"
  />
</p>

<p align="center">
  <img
    src="./assets/pixel-explorer.gif"
    width="640"
    alt="A pixel-art explorer walking through ancient ruins"
  />
</p>

<p align="center">
  <a href="https://github.com/mirandairene777">EXPLORE</a> ·
  <a href="#-featured-quests">DISCOVER</a> ·
  <a href="#-faith-and-the-journey">FAITH & THE JOURNEY</a>
</p>

> “Trust in the LORD with all your heart...” — Proverbs 3:5–6 (NLT)

I'm Irene — a Computer Science student exploring software, game development,
history, and the hope I have found in Jesus Christ.

## 🗺️ Featured Quests

- **Barangay Disaster Risk Profiler** — Python + MySQL for disaster-risk data.
- **Flo Tracker** — a Flutter period-tracking app built with my teammates.
- **LSPU Campus Navigator** — a Flutter campus navigation project.
- **Uncanny** — a collaborative 3D Unity game.

## ✝️ Faith and the Journey

My story is still being written. Jesus met me in difficult seasons, gave me hope,
and continues to teach me to trust Him one step at a time.

**The Gospel:** We have all sinned, but God showed His love through Jesus Christ,
who died for our sins and rose again. Salvation is a gift of grace, received
through faith in Him.

I want the things I learn and create to point beyond myself to the goodness of God.

<p align="center"><b>Soli Deo Gloria</b> · To God alone be the glory.</p>
