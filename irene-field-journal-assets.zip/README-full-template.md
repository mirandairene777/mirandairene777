# Irene's Field Journal

<p align="center">
  <img src="./assets/field-journal-banner.png" width="100%" alt="Irene's Field Journal pixel-art ruins banner" />
</p>

<p align="center">
  <img src="https://readme-typing-svg.demolab.com/?font=Tiny5&size=32&duration=2500&pause=900&color=F74FE7&center=true&vCenter=true&width=700&height=60&lines=Hi!+I'm+Irene;Welcome+to+my+Field+Journal;Exploring+history+%26+technology;Trusting+Jesus+along+the+way" alt="Typing introduction" />
</p>

<p align="center">
  <img src="./assets/pixel-explorer.gif" width="640" alt="A pixel-art explorer walking through ancient ruins" />
</p>

> **Field Note 001 — The Journey**
>
> “Trust in the LORD with all your heart...” — **Proverbs 3:5–6 (NLT)**

Hi! I'm Irene, a Computer Science student who loves learning, building digital
worlds, exploring history, and sharing the hope I found in Jesus Christ.

## 🧭 Explorer's Toolkit

`Python` · `Dart` · `Flutter` · `MySQL` · `JavaScript` · `Unity` · `Git`

## 🗺️ Featured Quests

| Quest | Field notes |
|---|---|
| **Barangay Disaster Risk Profiler** | Python + MySQL project focused on disaster-risk data. [Repository link](#) — replace this with the real public repo URL. |
| **Flo Tracker** | Flutter period-tracking app built with teammates. [View repository](https://github.com/mirandairene777/flo-tracker) |
| **LSPU Campus Navigator** | Flutter campus navigation project. [View repository](https://github.com/mirandairene777/LSPU-NAVIGATION-CAMPUS) |
| **Uncanny** | Collaborative 3D Unity game. [View team repository](https://github.com/matcha-jillyace/Uncanny) |

## ✝️ Faith and the Journey

My story is still being written. I have walked through painful seasons, but Jesus
has been my hope and continues to teach me to trust Him one step at a time.
I want to keep growing in faith, character, and skill — and use what I learn
for something good beyond myself.

### The Gospel — Good News

We have all sinned and fall short of God's glory. But God loves us: Jesus Christ
died for our sins and rose again, offering forgiveness and new life. We are saved
by God's grace through faith in Jesus, not by earning His love.

If you're searching for hope, peace, or a fresh start, you can seek Him.

## 📜 Current Expedition

- Learning and building with code, one project at a time.
- Exploring game development and useful applications.
- Growing in wisdom and trusting God with the path ahead.

<p align="center">
  <img src="https://readme-typing-svg.demolab.com/?font=Tiny5&size=22&duration=3000&pause=1000&color=F4D35E&center=true&vCenter=true&width=500&height=40&lines=Keep+exploring.;Keep+learning.;Keep+trusting+Jesus." alt="Keep exploring, learning, and trusting Jesus" />
</p>

<p align="center"><b>Soli Deo Gloria</b> · To God alone be the glory.</p>

<p align="center">
  <a href="https://github.com/mirandairene777">GitHub</a> ·
  <a href="https://irenemiranda.dev">Personal website</a>
</p>
